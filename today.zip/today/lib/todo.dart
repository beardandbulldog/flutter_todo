class Todo {
  Todo({this.title, this.isDone = false});

  String title;
  bool isDone;
}
