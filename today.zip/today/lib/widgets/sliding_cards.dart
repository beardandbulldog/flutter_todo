import 'package:flutter/material.dart';

class SlidingCardsView extends StatefulWidget {
  @override
  _SlidingCardsViewState createState() => _SlidingCardsViewState();
}

class _SlidingCardsViewState extends State<SlidingCardsView> {
  PageController pageController;

  @override
  void initState() {
    super.initState();
    pageController = PageController(viewportFraction: 0.8);
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: MediaQuery.of(context).size.height * 0.70,
      child: PageView(
        controller: pageController,
        children: <Widget>[
          SlidingCard(),
          SlidingCard(),
        ],
      ),
    );
  }
}

class SlidingCard extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.only(left: 12, top: 24, right: 12, bottom: 50),
      elevation: 16,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(32)),
      child: CardContent()
    );
  }

}

class CardContent extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
   return Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              CardHeader(),
              Divider (color: Color(0x4D000000),),
              ExpandCard(),
            ]
   );
  }
}

class ExpandCard extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Material(
        type: MaterialType.card,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
            splashColor: Colors.blue.withAlpha(30),
            onTap: (){
              Navigator.pop(context);
            },
             child: Row(
               mainAxisSize: MainAxisSize.max,
               mainAxisAlignment: MainAxisAlignment.center,
               children: <Widget>[
                 Padding(
                   padding: const EdgeInsets.all(4.0),
                   child: Icon(
                             Icons.add_circle,
                             color: Color(0xFF2D6567),
                             size:36.0,
                             semanticLabel: 'Text to announce in accessibility modes',
                           ),
                 ),
               ],
                ),
          ),
      );
  }
}



class CardHeader extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 24, top: 12, right: 24, ),
      child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(
              child: Text('Wednesday', style: Theme
                  .of(context)
                  .textTheme
                  .headline4),
            ),
            Container(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Text('10|02', style: Theme
                    .of(context)
                    .textTheme
                    .overline),
              ),
            ),
          ]
      ),
    );
  }
}