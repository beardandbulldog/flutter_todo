import 'package:flutter/material.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:today/widgets/bottomsheet_widget.dart';

class MyFloatingActionButton extends StatefulWidget {
  @override
  _MyFloatingActionButtonState createState() => _MyFloatingActionButtonState();
}

class _MyFloatingActionButtonState extends State<MyFloatingActionButton> {
  bool showFab = true;
  @override
  Widget build(BuildContext context) {
    return showFab
        ? showFloatingActionButton(false);
        bottomSheetController.closed.then((value) {
          showFloatingActionButton(true);
        }
        );

      },
    )
        : Container();
  }
  void showFloatingActionButton(bool value) {
    setState(() {
      showFab = value;
    });
  }
}

