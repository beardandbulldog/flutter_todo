import 'package:flutter/material.dart';
import 'package:today/utils/theme.dart';

class BottomSheetWidget extends StatefulWidget {
  @override
  _BottomSheetWidgetState createState() => _BottomSheetWidgetState();
}

class _BottomSheetWidgetState extends State<BottomSheetWidget> {


  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
        builder: (BuildContext context, myscrollController) {
          return Container(
            color: Colors.tealAccent[200],
            child: ListView.builder(
              controller: myscrollController,
              itemCount: 25,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                    title: Text(
                      'Dish $index',
                      style: TextStyle(color: Colors.black54),
                    ));
              },
            ),
          );
        }
    );
  }
}