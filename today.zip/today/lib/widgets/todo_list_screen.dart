import 'package:flutter/material.dart';
import 'package:today/todo.dart';

import 'package:today/widgets/todo_list.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:today/widgets/bottomsheet_widget.dart';

class TodoListScreen extends StatefulWidget {
  @override
  _TodoListScreenState createState() => _TodoListScreenState();

}

class _TodoListScreenState extends State<TodoListScreen> {
  List<Todo> todos = [];

  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  _toggleTodo(Todo todo, bool isChecked) {
    setState(() {
      todo.isDone = isChecked;
    });
  }

  _addTodo() async {
    final todo = await showModalBottomSheet<Todo>(
      context: context,
      builder: (BuildContext context) {
        return BottomSheetWidget();
      },
    );
    if (todo != null) {setState(() {
      todos.add(todo);
    });
    }
    }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        key: scaffoldKey,
        appBar: AppBar(title: Text('Todo List')),
        body: TodoList(
          todos: todos,
          onTodoToggle: _toggleTodo,
        ),
        floatingActionButton:  FloatingActionButton(
              child: Icon(Icons.add),
              onPressed: _addTodo,
        ),
      )
    );
  }
}

