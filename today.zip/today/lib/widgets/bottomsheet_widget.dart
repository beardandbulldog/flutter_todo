import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:today/utils/theme.dart';
import 'package:today/todo.dart';


class BottomSheetWidget extends StatefulWidget {
  @override
  _BottomSheetWidgetState createState() => _BottomSheetWidgetState();
}

class _BottomSheetWidgetState extends State<BottomSheetWidget> {
  List<Todo> todos = [];
  final myController = TextEditingController();
  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController.dispose();
    super.dispose();
  }


  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.card,
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      clipBehavior: Clip.antiAlias,
      color: Color(0xFFf2f2f2),
      child: Container(
        margin: const EdgeInsets.only(top: 5, left: 15, right: 15),
        child:  Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  TextFormField(
                    controller: myController,
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: 'What do yoou want to achieve today?',
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Enter a task you want to get done today';
                      }
                      return null;
                    },
                  ),
                  Padding (
                      padding: EdgeInsets.only(top:16.0),
                      child: Row (
                        mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                          FlatButton(
                                onPressed: Navigator.of(context).pop,
                                child: Text('Cancel')
                            ),
                            RaisedButton(
                              child: Text('Add item'),
                              onPressed: () {
                                if (_formKey.currentState.validate()) {
                                  print('Text Text Text');
                                  final todo = new Todo(title: myController.value.text);
                                  setState(() {
                                    todos.add(todo);});
                                  Navigator.of(context).pop(todo);}
                                },
                            )
                          ]
                      )
                  )
                ]
            )
        ),
      )
    );
  }
}
