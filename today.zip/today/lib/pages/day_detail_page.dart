
import 'package:flutter/material.dart';



class DayDetailPage extends StatelessWidget {
@override
Widget build(BuildContext context) {
  return Scaffold(
      backgroundColor: Color(0xFFFFFFFF),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                DayHeader(),
                Divider (color: Color(0x4D000000),),
                Expanded(
                  child: Placeholder(),
                )

               ]

            ),
          ),
        ]
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Color(0xFF2D6567),
        elevation: 4.0,
        icon: const Icon(Icons.add),
        label: const Text('Add a task'),
        onPressed: (){},

      ),
        floatingActionButtonLocation:FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: Container(
          decoration: BoxDecoration(boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 20)]),
            child: BottomAppBar(
              elevation: 1.0,
              child: new Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                    IconButton(
                      icon: Icon(Icons.menu),
                      onPressed: () {

                      }
                    ),
                    IconButton(
                      icon: Icon(Icons.unfold_less),
                      onPressed: () {

                      }
                   ),
                ]
              ),
            )
          ),
   );
 }
}

class DayHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 24, top: 12, right: 24, ),
        child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Container(
            child: Text('Wednesday', style: Theme
            .of(context)
            .textTheme
            .headline3),
    ),
          Container(
            child: Padding(
            padding: const EdgeInsets.only(bottom: 16),
             child: Text('10|02', style: Theme
            .of(context)
            .textTheme
            .overline),
    ),
    ),
    ]
    ),
    );
  }
  }
