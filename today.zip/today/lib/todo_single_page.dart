import 'package:flutter/material.dart';
import 'package:today/todo.dart';

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Todo> todos = [];

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  _toggleTodo(Todo todo, bool isChecked) {
    setState(() {
      todo.isDone = isChecked;
    });
  }

  _addTodo() async {
    final todo = await showModalBottomSheet<Todo>(
      context: context,
      builder: (BuildContext context) {
        return MyDraggableSheet();
      },
    );
    if (todo != null) {setState(() {
      todos.add(todo);
    });
    }
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(50.0), // here the desired height
          child: AppBar(
            title: Text('Scaffold Demo'),
            backgroundColor: Colors.deepOrange,
          )),
      drawer: Drawer(),
      body: new Center(),
      bottomSheet: MyDraggableSheet(),
    );
  }
}

class MyDraggableSheet extends StatefulWidget {
  @override
  _MyDraggableSheet createState() => _MyDraggableSheet();
}
List<Todo> todos = [];
final _formKey = GlobalKey<FormState>();
final myController = TextEditingController();

class _MyDraggableSheet extends State<MyDraggableSheet> {
  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.3,
      minChildSize: 0.1,
      maxChildSize: 1.0,
      builder: (BuildContext context, myScrollController) {
        return Material(
            type: MaterialType.card,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            clipBehavior: Clip.antiAlias,
            color: Color(0xFFf2f2f2),
            child: Container(
              color: Colors.tealAccent[200],
              child: Form(
                  key: _formKey,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        TextFormField(
                          controller: myController,
                          autofocus: true,
                          decoration: const InputDecoration(
                            hintText: 'What do yoou want to achieve today?',
                          ),
                          validator: (value) {
                            if (value.isEmpty) {
                              return 'Enter a task you want to get done today';
                            }
                            return null;
                          },
                        ),
                        Row (
                            children: [
                              Spacer (),
                              Padding(
                                padding: EdgeInsets.all(16.0),
                                child: FlatButton(
                                  onPressed: () {

                                  },
                                  child: Text(
                                      'Cancel',
                                  )

                                  )
                                )
                              ),
                              Padding (
                                padding: EdgeInsets.all(16.0),
                                child: FloatingActionButton.extended(
                                  icon: Icon(Icons.add),
                                  label: Text('Add an item'),
                                  onPressed: () {
                                    if (_formKey.currentState.validate()) {
                                      print('Text Text Text');
                                      final todo = new Todo(title: myController.value.text);
                                      setState(() {
                                        todos.add(todo);
                                        myController.dispose();
                                        super.dispose();
                                        }
                                        );
                                      }
                                  }
                                  )
                              )
                            ]
                        ),
                      ]
                  ),
                ),
        ),
        );
                },
    );

  }
}
